package com.desserts.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.desserts.demo.model.Desserts;
import com.desserts.demo.service.DessertsService;

@RestController

public class DessertsController {
	@Autowired
	DessertsService dessertsService;
	@GetMapping(value = "/fetchdesserts")
	public List<Desserts>getAllDesserts()
	{
		List<Desserts> dessertsList=dessertsService.getAllDesserts();
		return dessertsList;
	}
	@PostMapping(value = "/savedesserts")
	public Desserts saveDesserts(@RequestBody Desserts s)
	{
		return dessertsService.saveDesserts(s);
	}
	@PutMapping(value = "/updatedesserts")
	public Desserts updateDesserts(@RequestBody Desserts s)
	{
		return dessertsService.saveDesserts(s);
	}
	@DeleteMapping("/deletedesserts/{id}")
	public void deleteDesserts(@PathVariable("id")int id)
	{
		dessertsService.deleteDesserts(id);
	}
	@GetMapping(value = "/getdesserts/{id}")
	public Desserts getDesserts(@PathVariable("id")int id)
	{
		return dessertsService.getDesserts(id);
	}

}
