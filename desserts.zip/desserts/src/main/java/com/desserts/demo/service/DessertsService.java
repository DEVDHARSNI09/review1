package com.desserts.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.desserts.demo.model.Desserts;
import com.desserts.demo.repository.DessertsRepository;

@Service

public class DessertsService {
	@Autowired
	DessertsRepository dessertsRepository;
	public List<Desserts> getAllDesserts()
	{
		List<Desserts>dessertsList=dessertsRepository.findAll();
		return dessertsList;
	}
	public Desserts saveDesserts(Desserts s)
	{
		Desserts obj=dessertsRepository.save(s);
		return obj;
	}
	public Desserts updateDesserts(Desserts s)
	{
		Desserts obj1=dessertsRepository.save(s);
		return obj1;
	}
	public void deleteDesserts(int id)
	{
		dessertsRepository.deleteById(id);
	}
	public Desserts getDesserts(int id)
	{
		Desserts s=dessertsRepository.findById(id).get();
		return s;
	}
}