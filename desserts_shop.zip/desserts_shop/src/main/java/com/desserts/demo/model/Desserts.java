package com.desserts.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity

public class Desserts {
	@Id
	private int id;
	private String allergy_info;
	private String ingredients;
	private String name;
	private String net_weight;
	private float price;
	private long product_id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAllergy_info() {
		return allergy_info;
	}
	public void setAllergy_info(String allergy_info) {
		this.allergy_info = allergy_info;
	}
	public String getIngredients() {
		return ingredients;
	}
	public void setIngredients(String ingredients) {
		this.ingredients = ingredients;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getNet_weight() {
		return net_weight;
	}
	public void setNet_weight(String net_weight) {
		this.net_weight = net_weight;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public long getProduct_id() {
		return product_id;
	}
	public void setProduct_id(long product_id) {
		this.product_id = product_id;
	}
	
	
	
}
