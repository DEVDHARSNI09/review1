package com.desserts.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.desserts.demo.model.DessertsLoginModel;
import com.desserts.demo.repository.DessertsLoginRepository;

@Repository
public interface DessertsLoginRepository extends JpaRepository <DessertsLoginModel,Integer>{
	DessertsLoginModel findByusername(String username);

}
