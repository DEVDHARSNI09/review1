package com.desserts.demo.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.desserts.demo.model.Desserts;

@Repository

public interface DessertsRepository extends JpaRepository<Desserts,Integer> {
	@Query("select d from Desserts d where d.ingredients=?1 and d.name=?2")
    public List<Desserts> getDessertsByName(String ingredients,String name);
   //named parameter
   @Query("select d from Desserts d where d.name=:name")
   public List<Desserts> getDessertsByName(String name);
	//DML
	@Modifying
	@Query("delete from Desserts d where d.name=?1")
	public int deleteDessertsByName(String name);
   @Modifying
   @Query("update Desserts d set d.ingredients=?1 where d.name=?2")
   public int updateDessertsByName(String ingredients,String name);
   
   @Query(value="select * from desserts d where d.name=?1",nativeQuery=true)
   public List<Desserts> getDataDesserts (String name);
   
   
   
   
  
}
