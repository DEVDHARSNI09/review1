package com.desserts.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.desserts.demo.model.Desserts;
import com.desserts.demo.service.DessertsService;


import org.springframework.http.HttpStatus;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController

public class DessertsController {
	@Autowired
	DessertsService dessertsService;
	
	@Operation(summary = "Get all the desserts")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "successful"),
			@ApiResponse(responseCode = "401", description = "Invalid credentials"),
			@ApiResponse(responseCode = "404", description = "Path not found") })
	@ResponseStatus(HttpStatus.CREATED)
	@GetMapping(value = "/fetchdesserts")
	public List<Desserts>getAllDesserts()
	{
		List<Desserts> dessertsList=dessertsService.getAllDesserts();
		return dessertsList;
	}
	@PostMapping(value = "/savedesserts")
	public Desserts saveDesserts(@RequestBody Desserts s)
	{
		return dessertsService.saveDesserts(s);
	}
	@PutMapping(value = "/updatedesserts")
	public Desserts updateDesserts(@RequestBody Desserts s)
	{
		return dessertsService.saveDesserts(s);
	}
	@DeleteMapping("/deletedesserts/{id}")
	public void deleteDesserts(@PathVariable("id")int id)
	{
		dessertsService.deleteDesserts(id);
	}
	@GetMapping(value = "/getdesserts/{id}")
	public Desserts getDesserts(@PathVariable("id")int id)
	{
		return dessertsService.getDesserts(id);
	}
	//sorting
		@GetMapping(value="/sort/{id}")
		public List<Desserts> sortStudents(@PathVariable("id") String id)
		{
			return dessertsService.sortStudents(id);
		}
		@GetMapping(value="/dessertsSorting/{id}")
		public List<Desserts> sortDesserts(@PathVariable("id") String id)
		{
			return dessertsService.sortDesserts(id);
		}
		@GetMapping(value="/dessertsSorting1/{id}")
		public List<Desserts> sortDesserts1(@PathVariable("id") String id)
	    {
			return dessertsService.sortDesserts1(id);
		}
		@GetMapping(value="pagenation/{offset}/{pagesize}")
		public List<Desserts> getDessertsDetails(@PathVariable int offset,@PathVariable int pagesize)
		{
			return dessertsService.getDessertsDetails(offset,pagesize);
		}
		@GetMapping("/pagenationSorting/{offset}/{pagesize}/{id}")
		public List<Desserts>getdesserts(@PathVariable int offset,@PathVariable int pagesize,@PathVariable String id)
		{
			return dessertsService.getDessertsSort(offset,pagesize,id);
		}
		@GetMapping("/fetchByName")
		public List<Desserts> getDessertsByName(@RequestParam String name)
		{
			return dessertsService.getDessertsByName(name);
		}
		
		@GetMapping("/fetchByIngredient/{ingredients}/{name}")
		public List<Desserts> getDessertsByName(@PathVariable String ingredients, @PathVariable String name)
		{
			return dessertsService.getDessertsByName(ingredients,name);
		}
		@DeleteMapping("/deleteDessertByName/{name}")
	    public String deleteDessertsByName(@PathVariable String name)
	    {
	 	   int result = dessertsService.deleteDessertsByName(name);
	 	   if(result>0)
	 		     return "record deleted";
	 	   else
	 		     return "Problem occured while deleting";
	    }
	    @PutMapping("/updateDessertByName/{ingredients}/{name}")
	    public String updateDessertsByName(@PathVariable String ingredients,@PathVariable String name)
	    {
	 	   int res = dessertsService.updateDessertsByName(ingredients, name);
	 	   if(res>0)
	 		      return "Customer record updated";
	 	   else
	 		    return "Problem occured";
	    }
	    @GetMapping("/getDataDesserts")
		public List<Desserts> getDataBooks(@RequestParam String name)
		{
			return dessertsService.getDataDesserts(name);
		}
	    
}
