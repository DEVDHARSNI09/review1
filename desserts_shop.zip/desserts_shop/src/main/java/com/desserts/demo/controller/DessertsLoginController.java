package com.desserts.demo.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.desserts.demo.service.DessertsLoginService;


@RestController
public class DessertsLoginController {
	@Autowired
	DessertsLoginService dls;
		@PostMapping("/login")
		public String login(@RequestBody Map<String,String> loginDataMap)
		{
			String username = loginDataMap.get("username");
			String password = loginDataMap.get("password");
			String result = dls.loginCheckData(username, password);
			return result;
		}

}
