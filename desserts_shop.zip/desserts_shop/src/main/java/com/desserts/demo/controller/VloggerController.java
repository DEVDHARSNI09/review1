package com.desserts.demo.controller;

  import java.util.List;

    import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.web.bind.annotation.GetMapping;
	import org.springframework.web.bind.annotation.PostMapping;
	import org.springframework.web.bind.annotation.RequestBody;
	import org.springframework.web.bind.annotation.RestController;

import com.desserts.demo.model.Vlogger;
import com.desserts.demo.service.VloggerService;



	@RestController
	public class VloggerController {
	@Autowired
	VloggerService vservice;
	@GetMapping("/getAllVloggers")
	public List<Vlogger>fetchAllVloggers()
	{
		return vservice.fetchAllVloggers();
	}
	@PostMapping(value="/saveVlogger")
	public Vlogger saveVlogger(@RequestBody Vlogger v)
	{
		return vservice.saveVlogger(v);
	}
}

