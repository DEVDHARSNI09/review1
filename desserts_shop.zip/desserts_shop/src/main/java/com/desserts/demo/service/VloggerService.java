package com.desserts.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.desserts.demo.model.Vlogger;
import com.desserts.demo.repository.VloggerRepository;

	
	@Service
	public class VloggerService {
	@Autowired
	VloggerRepository vloggerRepo;
	public List<Vlogger>fetchAllVloggers()
	{
		return vloggerRepo.findAll();
	}
	public Vlogger saveVlogger(Vlogger v)
	{
		return vloggerRepo.save(v);
	}
}

