package com.desserts.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.desserts.demo.model.Desserts;
import com.desserts.demo.repository.DessertsRepository;

import jakarta.transaction.Transactional;

@Service

public class DessertsService {
	@Autowired
	DessertsRepository dessertsRepository;
	public List<Desserts> getAllDesserts()
	{
		List<Desserts>dessertsList=dessertsRepository.findAll();
		return dessertsList;
	}
	public Desserts saveDesserts(Desserts s)
	{
		Desserts obj=dessertsRepository.save(s);
		return obj;
	}
	public Desserts updateDesserts(Desserts s)
	{
		Desserts obj1=dessertsRepository.save(s);
		return obj1;
	}
	public void deleteDesserts(int id)
	{
		dessertsRepository.deleteById(id);
	}
	public Desserts getDesserts(int id)
	{
		Desserts s=dessertsRepository.findById(id).get();
		return s;
	}
	public List<Desserts> sortStudents(String id) {
		return  dessertsRepository.findAll(Sort.by(id));
	}
	public List<Desserts> sortDesserts(String id) {
		 return dessertsRepository.findAll(Sort.by(id).ascending());
	}
	public List<Desserts> sortDesserts1(String id) {
		 return dessertsRepository.findAll(Sort.by(id).descending());
	}
	public List<Desserts> getDessertsDetails(@PathVariable int offset,@PathVariable int pagesize) {
		Page <Desserts> page=dessertsRepository.findAll(PageRequest.of(offset, pagesize));
		return page.getContent();
	}
	public List<Desserts> getDessertsSort(int offset, int pagesize, String id) {
		PageRequest paging=PageRequest.of(offset, pagesize,Sort.by(id));
		Page<Desserts>page=dessertsRepository.findAll(paging);
		return page.getContent() ;
	}
	

	public List<Desserts> getDessertsByName(String ingredients,String name)
	  {
		  return dessertsRepository.getDessertsByName(ingredients, name);
	  }
	
	@Transactional 
	public int deleteDessertsByName(String name)
	{
 	return dessertsRepository.deleteDessertsByName(name);
	}
	@Transactional
	public int updateDessertsByName(String ingredients,String name)
	{
		return dessertsRepository.updateDessertsByName(ingredients, name);
	}
	public List<Desserts> getDessertsByName(String name) {
		return dessertsRepository.getDessertsByName(name);
	}
	public List<Desserts> getDataDesserts(String name ) {
		return dessertsRepository.getDataDesserts(name);
	}
	
}