package com.desserts.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.desserts.demo.repository.DessertsLoginRepository;
import com.desserts.demo.model.DessertsLoginModel;

@Service
public class DessertsLoginService {
	@Autowired
	DessertsLoginRepository dlr;
	public String loginCheckData(String username,String password)
	{
		DessertsLoginModel user = dlr.findByusername(username);
		if(user == null)
		{
			return "No User Found.Please Try Again!";
		}
		else
		{
			if(user.getPassword().equals(password))
			{
				return "Login Successful";
			}
			else
			{
				return "Login Failed";
			}
		}
	}

}
