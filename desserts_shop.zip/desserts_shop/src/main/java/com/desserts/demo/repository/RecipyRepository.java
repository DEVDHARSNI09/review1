package com.desserts.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.desserts.demo.model.Recipy;


@Repository
public interface RecipyRepository extends JpaRepository<Recipy,Long>{
	
}
